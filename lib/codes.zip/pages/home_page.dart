import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final user = FirebaseAuth.instance.currentUser!;
  

  // get user details from user coll in db
Future<Map<String, dynamic>?> getUserDetails() async {
  try {
    final user = FirebaseAuth.instance.currentUser;
    
    if (user != null) {
      print('User ID: ${user.uid}');
      final db = FirebaseFirestore.instance;
      final userRef = db.collection('users').doc(user.uid);
      final userSnapshot = await userRef.get();

      if (userSnapshot.exists) {
        return userSnapshot.data() as Map<String, dynamic>;
      } else {
        print('User document does not exist');
        return null;
      }
    } else {
      print('User is not logged in');
      return null;
    }
  } catch (e) {
    print('Error fetching user details: $e');
    return null;
  }
}


  //store user details in a map
  Map<String, dynamic> userDetails = {};

  // @override
  // void initState() {
  //   super.initState();
  //   // Use await here to wait for the Future to complete
  //   getUserDetails().then((result) {
  //     // Check if result is not null before assigning it to userDetails
  //     if (result != null) {
  //       setState(() {
  //         userDetails = result as Map<String, dynamic>;
  //         print("----------------");
  //         print(userDetails);
  //       });
  //     }
  //   });
  // }

  // get user  details from user collection in the database and check if role is admin
  Future<bool> isAdmin() async {
    final db = FirebaseFirestore.instance;
    final userRef = db.collection('users').doc(user.uid);

    final doc = await userRef.get();

    if (doc.exists) {
      return doc.data()!['role'] == 'admin';
    } else {
      return false;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Cyclops'),
          centerTitle: true,
          backgroundColor: Colors.blue[400],
          elevation: 10,
          leading: FutureBuilder<bool>(
            future: isAdmin(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                // Return a loading indicator or placeholder while waiting for the result
                return CircularProgressIndicator();
              } else if (snapshot.hasError) {
                // Handle errors
                return Icon(Icons.error);
              } else if (snapshot.data == true) {
                // Return the admin icon if the user is an admin
                return Icon(Icons.admin_panel_settings_outlined);
              } else {
                // Return null if the user is not an admin
                return Container();
              }
            },
          ),
          actions: [
            IconButton(
              onPressed: () async {
                await FirebaseAuth.instance.signOut();
                Navigator.pushNamed(context, '/main');
              },
              icon: const Icon(Icons.logout),
            ),
            // Conditional display of the register link based on user's role
            // if (isAdmin())
            //   TextButton(
            //     onPressed: () {
            //       // Navigate to the register page
            //       Navigator.pushNamed(context, '/register');
            //     },
            //     child: Text(
            //       'Register',
            //       style: TextStyle(color: Colors.white),
            //     ),
            //   ),
          ],
        ),
        backgroundColor: Colors.blue[400],
        body: SafeArea(
          child: FutureBuilder<Map<String, dynamic>?>(
            future: getUserDetails(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return CircularProgressIndicator();
              } else if (snapshot.hasError || snapshot.data == null) {
                return Text('Error fetching user details');
              } else {
                userDetails = snapshot.data!;
                return Container(
                  // alignment: FractionalOffset.bottomCenter,
                  decoration: BoxDecoration(
                    // color: Colors.white,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Stack(
                        // fit: StackFit.passthrough,
                        // alignment: Alignment.bottomCenter,
                        children: [
                          Container(
                            height: 600,
                            margin: EdgeInsets.only(top: 100),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(60),
                                  topRight: Radius.circular(60)),
                            ),
                            child: Column(
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceEvenly,
                                  children: [
                                    GestureDetector(
                                      onTap: () => Navigator.pushNamed(
                                          context, '/visitor_in'),
                                      child: Container(
                                        margin: EdgeInsets.only(
                                            left: 20,
                                            right: 5,
                                            top: 140,
                                            bottom: 30),
                                        height: 200,
                                        width: 170,
                                        padding: EdgeInsets.all(10),
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Container(
                                                // margin: EdgeInsets.only(top: 20),
                                                height: 120,
                                                padding: EdgeInsets.all(20),
                                                decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  borderRadius:
                                                      BorderRadius.circular(20),
                                                ),
                                                child: Image.asset(
                                                    'assets/images/check_in.png')),
                                            SizedBox(height: 10),
                                            Text(
                                              'Check In',
                                              style: TextStyle(
                                                fontSize: 16,
                                                fontWeight: FontWeight.w400,
                                                color: Colors.black,
                                              ),
                                            ),
                                          ],
                                        ),
                                        decoration: BoxDecoration(
                                            color: Colors.grey[50],
                                            borderRadius:
                                                BorderRadius.circular(20),
                                            boxShadow: [
                                              // darker right
                                              BoxShadow(
                                                color: Colors.grey.shade500,
                                                spreadRadius: 1,
                                                blurRadius: 10,
                                                offset: Offset(3, 3),
                                              ),

                                              // lighter left
                                              BoxShadow(
                                                color: Colors.grey.shade500,
                                                spreadRadius: 1,
                                                blurRadius: 10,
                                                offset: Offset(-3, -3),
                                              ),
                                            ]),
                                      ),
                                    ),
                                    GestureDetector(
                                      onTap: () => Navigator.pushNamed(
                                          context, '/visitor_out'),
                                      child: Container(
                                        margin: EdgeInsets.only(
                                            left: 5,
                                            right: 20,
                                            top: 140,
                                            bottom: 30),
                                        padding: EdgeInsets.all(10),
                                        height: 200,
                                        width: 170,
                                        child: Column(
                                          mainAxisAlignment:
                                              MainAxisAlignment.center,
                                          children: [
                                            Container(
                                                // margin: EdgeInsets.only(top: 20),
                                                height: 120,
                                                padding: EdgeInsets.all(20),
                                                decoration: BoxDecoration(
                                                  color: Colors.white,
                                                  borderRadius:
                                                      BorderRadius.circular(20),
                                                  // border: Border.all(
                                                  //   color: Colors.black,
                                                  //   width: 1,
                                                  // )
                                                ),
                                                child: Image.asset(
                                                    'assets/images/check-out.png')),
                                            SizedBox(height: 10),
                                            Text(
                                              'Visitor\nCheck Out',
                                              style: GoogleFonts.mavenPro(
                                                textStyle: TextStyle(
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.black,
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                        decoration: BoxDecoration(
                                            color: Colors.grey[50],
                                            borderRadius:
                                                BorderRadius.circular(20),
                                            boxShadow: [
                                              // darker right
                                              BoxShadow(
                                                color: Colors.grey.shade500,
                                                spreadRadius: 1,
                                                blurRadius: 10,
                                                offset: Offset(3, 3),
                                              ),

                                              // lighter left
                                              BoxShadow(
                                                color: Colors.grey.shade300,
                                                spreadRadius: 1,
                                                blurRadius: 10,
                                                offset: Offset(-3, -3),
                                              ),
                                            ]),
                                      ),
                                    ),
                                  ],
                                ),
                                GestureDetector(
                                  onTap: () => Navigator.pushNamed(
                                      context, '/visitor_logs'),
                                  child: Container(
                                    height: 150,
                                    decoration: BoxDecoration(
                                        color: Colors.grey[50],
                                        borderRadius: BorderRadius.circular(20),
                                        boxShadow: [
                                          // darker right
                                          BoxShadow(
                                            color: Colors.grey.shade500,
                                            spreadRadius: 1,
                                            blurRadius: 10,
                                            offset: Offset(3, 3),
                                          ),

                                          // lighter left
                                          BoxShadow(
                                            color: Colors.grey.shade300,
                                            spreadRadius: 1,
                                            blurRadius: 10,
                                            offset: Offset(-3, -3),
                                          ),
                                        ]),
                                    margin: EdgeInsets.symmetric(
                                        horizontal: 20, vertical: 10),
                                    child: Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Container(
                                            // margin: EdgeInsets.only(top: 20),
                                            height: 120,
                                            width: 150,
                                            padding: EdgeInsets.all(20),
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius:
                                                  BorderRadius.circular(20),
                                              // border: Border.all(
                                              //   color: Colors.black,
                                              //   width: 1,
                                              // )
                                            ),
                                            child: Image.asset(
                                                'assets/images/logbook.png')),
                                        SizedBox(width: 10),
                                        Text(
                                          'Visitor\nLogs',
                                          style: GoogleFonts.acme(
                                            textStyle: TextStyle(
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold,
                                              color: Colors.black,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            height: 200,
                            padding: EdgeInsets.all(10),
                            margin: EdgeInsets.symmetric(
                                horizontal: 50, vertical: 10),
                            decoration: BoxDecoration(
                              color: Colors.deepOrange[200],
                              borderRadius: BorderRadius.circular(20),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.deepOrange.withOpacity(0.3),
                                  spreadRadius: 5,
                                  blurRadius: 10,
                                  offset: Offset(
                                      0, 3), // changes position of shadow
                                ),
                              ],
                            ),
                            child: Text(
                              'Welcome, ${userDetails['FirstName']}',
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Colors.black,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                );
              }
            },
          ),
        ));
  }
}
