import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cyclops/components/my_button.dart';
import 'package:cyclops/components/my_textfield.dart';
import 'package:firebase_auth/firebase_auth.dart';
// import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter/material.dart';

class RegisterPage extends StatefulWidget {
  final VoidCallback showLoginPage;
  const RegisterPage({super.key, required this.showLoginPage});

  // Initial dropdown value
  static const String dropdownValue = 'Select Role';

  //List of dropdown values
  static const List<String> dropdownValues = <String>[
    'admin',
    'guard',
  ];

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final _firstNameController = TextEditingController();
  final _lastNameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  final _roleController = TextEditingController();
  final _phoneContactController = TextEditingController();
  final _officialIdController = TextEditingController();

  // bool _loading = false;

  bool passwordConfirmed() {
    if (_passwordController.text.trim() ==
        _confirmPasswordController.text.trim()) {
      return true;
    } else {
      // print('Passwords do not match');

      return false;
    }
  }

  Future addUserDetails(
    String firstName,
    String lastName,
    String email,
    String role,
    String phoneContact,
    String officialId,
    String uid,
  ) async {
    final db = FirebaseFirestore.instance;
    final userRef = db.collection('users').doc();
    // add timestamp
    final createdAt = FieldValue.serverTimestamp();

    // final data payload
    final userData = {
      'userId': userRef.id,
      'firstName': firstName,
      'lastName': lastName,
      'email': email,
      'role': role,
      'phoneContact': phoneContact,
      'officialId': officialId,
      'createdAt': createdAt,
      'uid': uid,
    };

    try {
      await userRef.set(userData);
      print('---------User added to firestore------');

      // await FirebaseFunctions.instance.httpsCallable('setCustomClaims')({});
      // print('-----------------Custom claims set---------');
    } catch (e) {
      print(e);
    }
  }

  Future signUp() async {
    // check if passwords match

    // print(_roleController.text.trim());

    // setState(() {
    //   _loading = true;
    // });
    //capture context
    // BuildContext currentContext = context;

    showDialog(
      context: context,
      builder: ((context) {
        return const Center(child: CircularProgressIndicator());
      }),
    );

    if (passwordConfirmed()) {
      await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
      );
    }
    try {
      // add user details to firestore
      // Obtain user details after user creation
      User? user = FirebaseAuth.instance.currentUser;
      String UserUid = user!.uid.toString().trim();
      print('User UID: $UserUid');
      // if (user != null) 
        // Pass user.uid to addUserDetails
        await addUserDetails(
          _firstNameController.text.trim(),
          _lastNameController.text.trim(),
          _emailController.text.trim(),
          _roleController.text.trim(),
          _phoneContactController.text.trim(),
          _officialIdController.text.trim(),
          UserUid,
        );
      
    } on Exception catch (e) {
      // TODO
      print("Registration Error: $e");
    } finally {
      // ignore: use_build_context_synchronously
      Navigator.of(context).pop();
    }

    // setState(() {
    //   _loading = false;
    // });

    // if (context.mounted && _loading) Navigator.of(context).pop();

    // Builder(
    //   builder: (BuildContext context) {
    //     Navigator.of(context).pop();
    //     return Container();
    //   },
    // );
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color(0xff1A73E8),
        body: SafeArea(
          child: SingleChildScrollView(
            child: Column(children: [
              Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(100),
                ),
                margin: EdgeInsets.only(top: 100),
                child: Center(
                  child: ClipOval(
                    child: Image.asset(
                      'assets/images/splash_logo.png',
                      width: 200,
                      height: 200,
                    ),
                  ),
                ),
              ),
              const SizedBox(
                height: 20,
              ),
              const Text(
                'Welcome to\n Checkpoint',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 30,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Text(
                'Register your details below',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 18,
                ),
              ),
              SizedBox(
                height: 20,
              ),
              MyTextField(
                  controller: _firstNameController,
                  hintText: 'First Name',
                  obscureText: false),
              MyTextField(
                  controller: _lastNameController,
                  hintText: 'Last Name',
                  obscureText: false),
              MyTextField(
                  controller: _emailController,
                  hintText: 'Email',
                  obscureText: false),
              MyTextField(
                  controller: _passwordController,
                  hintText: 'Password',
                  obscureText: true),
              MyTextField(
                  controller: _confirmPasswordController,
                  hintText: 'Confirm Password',
                  obscureText: true),
              SizedBox(
                height: 20,
              ),
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: DropdownMenu(
                    controller: _roleController,
                    hintText: 'Role',
                    width: 300,
                    inputDecorationTheme: InputDecorationTheme(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(
                          color: Colors.white,
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(
                          color: Colors.white,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(
                          color: Color(0xFFFB38A3),
                        ),
                      ),
                    ),
                    dropdownMenuEntries: RegisterPage.dropdownValues.map(
                      (String value) {
                        return DropdownMenuEntry<String>(
                          label: value,
                          value: value,
                        );
                      },
                    ).toList()),
              ),
              MyTextField(
                  controller: _phoneContactController,
                  hintText: 'Phone Contact',
                  obscureText: false),
              MyTextField(
                  controller: _officialIdController,
                  hintText: 'Official ID',
                  obscureText: false),
              SizedBox(height: 20),
              MyButton(
                onPressed: signUp,
                btnText: 'Register',
              ),
              SizedBox(height: 20),
              GestureDetector(
                onTap: widget.showLoginPage,
                child: Text(
                  'Login here',
                  style: TextStyle(
                      color: Color(0xFFFB38A3),
                      fontSize: 18,
                      fontWeight: FontWeight.bold),
                ),
              ),
            ]),
          ),
        ));
  }
}
